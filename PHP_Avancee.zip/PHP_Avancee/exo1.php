<!DOCTYPE html>
<html>
<body>

<?php

/* Consigne:
    Créez une fonction qui prend en argument un tableau de nombres et une valeur entière donnant la position pour spliter
    le tableau en deux. Si la valeur de la position est supérieure à la longueur du tableau, retournez le.
    Vous pouvez utiliser la fonction array_shift de PHP pour dépiler le tableau.
 */

// signature: split_array(array $numbers, int $pos, bool $preserve = false): array

function split_array(array $numbers, int $pos, bool $preserve = false): array {
    $length = count($numbers);
    $array1 = [];
    
    if($pos>=$length){
        return [$numbers,[]];
    }
    if($pos>=0)
    {
        for($i = 0;$i<$pos;$i++){//for each
            $array1[] = array_shift($numbers);
            print_r($array1);
        }
       // print_r($array1);
        return [$array1, $numbers];
    }
    
    for($i = 0;$i<$length+$pos;$i++){
        $array1[] = array_shift($numbers);
    }
    //print_r($array1);
    return [$array1, $numbers];
    
}

$result = split_array(numbers: [4,6,9, 17], pos : 3);
var_dump($result === [[4,6,9], [17]]);

$result = split_array(numbers: [4,6,9, 17], pos : -2);
var_dump($result === [[4,6] , [9, 17]]);

$result = split_array(numbers: [4,6,9, 17], pos : 20);
var_dump($result === [[4,6, 9, 17], []]);

$result = split_array(numbers: [4,6,9, 17], pos : -20);
var_dump($result === [[], [4,6, 9, 17]]);

$result = split_array(numbers: [2 => 4, 3 => 6], pos : 1);
var_dump($result === [[0 => 4], [0 => 6]]);

$result = split_array(numbers: [2 => 4, 3 => 6], pos : 1, preserve: true);
var_dump($result === [[2 => 4], [3 => 6]]);

?>

</body>
</html>