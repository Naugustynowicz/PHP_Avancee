<?php

use Symfony\Component\HttpFoundation\Request;
//use angular-codeigniter-seed\api\application\helpers\jwt_helper;

require_once __DIR__.'/../vendor/autoload.php';

$request = Request::createFromGlobals();

$path = $request->getPathInfo();
$method = $request->getMethod();

// Fonctions et classes utiles
// Au choix, faire avec les fonctions php ou les classes Symfony
// php :
    // header : https://www.php.net/manual/fr/function.header.php
    // symfony : https://symfony.com/doc/current/components/http_foundation.html
    // Request
    // Response
    // JsonResponse

// questions :
    // requpete vs réponse http
    // code http ?
    // status http ?
    // headers
        // types mimes
// liens :
    // Général : https://developer.mozilla.org/fr/docs/Web/HTTP/Overview
    // Headers : https://developer.mozilla.org/fr/docs/Web/HTTP/Headers
    // Méthodes http : https://developer.mozilla.org/fr/docs/Web/HTTP/Methods

// créer une fonction chargée de rendre le html
// rappel : never trust user input


function getPage(string $page): string {
    // doit être mis dans une fonction réutilisable
    ob_start();
        require_once __DIR__.'/../templates/'.$page;
    return ob_get_clean();
}

$content = '';
$id = -1 ;
// accepte uniquement les requêtes 'GET'
if ($path === '/' && $method === 'GET') {
    $content = getPage('home.html');
    
    // par défaut
    header('Content-Type: text/html');
}

// définir une route about
// accepte uniquement les requête GET
else if ($path === '/about' && $method === 'GET') {
    $content = getPage('about.html');
    
    // par défaut
    header('Content-Type: text/html');
}

// définir une route blog
// accepte uniquement les requêtes GET et POST
else if ($path === '/blog' && ($method === 'GET' || $method === 'POST')) {
    $content = getPage('blog.html');
    
    // par défaut
    header('Content-Type: text/html');
}
// définir une route blog/post
// accepte uniquement les requêtes GET
// récupére un paramètre id et l'affiche dans la page blog_show.html
else if ($path === '/blog/post' && $method === 'GET') {
    
    $id = $_GET['id'];
    //if(gettype($id)==='integer'){
    $id = $_POST['id'];
    $content = getPage('blog_show.php');
    //}
    // par défaut
    header('Content-Type: text/html');
}


// définir une route api/token
// accepte uniquement les requêtes GET
// renvoie un token sous le format JSON
// vérifier les entêtes
/*
else if ($path === '/api/token' && $method === 'GET') {
    $token = array();
    $token['id'] = 'test01';
    echo JWT::encode($token, 'secret_server_key');
}
*/

else {
    $content = getPage('error.html');
    
    // par défaut
    header('Content-Type: text/html');
    // créer une page html d'erreur
    // $content = require la page error.html
    // renvoyer un code 404
}



echo $content;

?>