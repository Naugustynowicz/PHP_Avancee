<!DOCTYPE html>
<html>
<body>

<?php

// value object, son but est de gérer des données
class Route
{
    public const AVAILABLE_METHODS = ['GET', 'POST'];

    private string $path;
    private array $methods;

    public function __construct(string $path, array $methods = self::AVAILABLE_METHODS)
    {
        $this->setPath($path);
        $this->setMethods($methods);
    }

    public function getPath(): string
    {
        return $this->path;
    }

    public function setPath(string $path): void
    {
public function setMethods(array $methods): void
    {
        foreach ($methods as $method) {
            // Grâce à l'encapsulation, on s'assure que l'utilisateur de notre class
            // fournit des données cohérentes
            if (!$this->isValidMethod($method)) {
                throw new InvalidArgumentException(
                    sprintf('Method "%s" is not a valid method. Available methods are: %s',
                        $method, implode(', ', self::AVAILABLE_METHODS)
                    )
                );
            }
        }

        $this->methods = $methods;
    }

    // encapsulation, cette méthode est privée car concerne uniquemen
    // le fonctionnement interne de la classe
    private function isValidMethod(string $method): bool
    {
        return in_array($method, self::AVAILABLE_METHODS);
    }

// service object, permet d'effectuer des tâches
class Router
{
    private array $routes = [];

    /**
     * @throws Exception
     */
    public function match(string $path): Route
    {
        foreach ($this->routes as $route) {
            if ($route->getPath() === $path) {
                return $route;
            }
        }

        throw new Exception('Resource not found...');
    }

    public function add(string $name, Route $route): void
    {
        $this->routes[$name] = $route;
    }
}

$router = new Router();
$router->add('blog', new Route('blog'));

try {
    var_dump($router->match('/blog'));
} catch (Exception $e) {
    var_dump($e->getMessage());
}


?>

</body>
</html>