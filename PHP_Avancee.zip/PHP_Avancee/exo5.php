<!DOCTYPE html>
<html>
<body>

<?php

class BaseArray
{
    private array $items = [];

    // creer une méthode pour ajouter des éléments à $this->items
    public function add(string|int $index, mixed $element): self {
        $this->items[$index] = $element;

        return $this;
    }

    // creer une méthode pour supprimer des éléments à $this->items
    public function remove(string|int $index): void {
        if ($this->items[$index]) {
            unset($this->items[$index]);
        }
    }

    // creer une méthode pour récupérer tous les éléments de $this->items
    public function all(): array {
        return $this->items;
    }
    
    //change la casse de toutes les clés du tableau
    public function change_keys_case(string $case): void 
    {
        foreach($this->items as $index => $element)
        {
            if(gettype($index) === "string")
            {
                switch($case)
                {
                    case "Maj" :
                        $this->remove($index);
                        $this->add(strtoupper($index), $element);
                        break;
                    case "Min" :
                        $this->remove($index);
                        $this->add(strtolower($index), $element);
                        break ;
                }
            }
        }
    }
    
    // Effectuer un filtrage sur le tableau via $fn
    // Ne pas modifier $this->array
    // retourner le filtre
    public function filter(callable $fn, string $case): array {
        $filtre = [];
        foreach($this->items as $index => $element)
        {
            switch($case)
                {
                    case "key":
                        if($fn($index) === true){
                            $filtre[$index] = $element;
                        }
                    case "both":
                        if($fn($index,$element) === true){
                            $filtre[$index] = $element;
                        }
                    default :
                        if($fn($element) === true){
                            $filtre[$index] = $element;
                        }
                }
        }
        return $filtre;
    }

}

$items = new BaseArray();

$items->add('item_1', 1)
    ->add('item_2', 2)
    ->add(3,3);
var_dump($items->all());

$items->change_keys_case("Maj");
var_dump($items->all());

$items->change_keys_case("Min");
var_dump($items->all());

var_dump($items->filter(function($a){return $a == 2;},""));
var_dump($items->filter(function($a){return $a == 'item_1';},"key"));
var_dump($items->filter(function($a, $b){return $a == 'item_1' || $b == 1;},"both"));




?>

</body>
</html>