<!DOCTYPE html>
<html>
<body>

<?php

// Créez une fonction permettant de regrouper terme à terme les éléments de deux tableaux de dimension 1.
// Elle retournera un tableau de dimension 2 regroupant les éléments.

function zip(array $tab1, array $tab2){
    $length = max(count($tab1,$tab2));
    for($i=)
}


$result = zip(tab1 : [1,2,3], tab2: [4,5,6]);
var_dump($result === [[1,4], [2,5], [3,6]]);

$result = zip(tab1 : [], tab2: []);
var_dump($result === []);

$result = zip(tab1 : [], tab2: [4,5,6]);
var_dump($result === [[4], [5], [6]]);

$result = zip(tab1 : [4,5,6], tab2: []);
var_dump($result === [[4], [5], [6]]);

$result = zip(tab1 : [1,2,3,4], tab2: [4,5,6]);
var_dump($result === [[1,4], [2,5], [3, 6], [4]]);

$result = zip(tab1 : [1,2,3], tab2: [4,5,6,7,8]);
var_dump($result === [[1,4], [2,5], [3, 6], [7], [8]]);


?>

</body>
</html>